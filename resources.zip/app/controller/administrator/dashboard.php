<?php
class dashboard extends shl_controller
{
	function index()
	{
		shl_loader::view("administrator/ultimo/home");
	}	
}
?>