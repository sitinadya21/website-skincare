<?php

class transaksi extends shl_controller

{

	function __construct()

	{

		shl_loader::model("administrator/general/m_transaksi");

	}



	function index($datasource = "")

	{

		if (empty($datasource))

		{

			$datasource = m_transaksi::get_data();

		}



		$page = input_get("page");

		$page = (empty($page)) ? "1" : $page;

		self::$data['transaksi'] = shl_pagination::page($page)

											 ->paginate($datasource);



		shl_loader::view("administrator/ultimo/general/transaksi", self::$data);

	}



	function search()

    {

        self::index(m_transaksi::search(input_get("s")));

    }



    function tambah()

    {

        self::simpan("tambah");

    }



    function perbaiki()

    {

        self::simpan("perbaiki");

    }



    function hapus()

    {

        if (m_transaksi::delete(url_segment(5)))

        {

            redirect("administrator/general/transaksi");

        }

    }



    function simpan($aksi = '')

    {

        shl_form::rule("status_transaksi", "required", "Form");

        

        if (shl_form::is_valid())

        {

            $data = $_POST;





            if ($data['status_transaksi'] == 'On Progress') {



            $keranjang = shl_db::table("keranjang")->where("id_transaksi", url_segment(5))->get();

            foreach ($keranjang as $row) {



                $cek_produk=shl_db::table("produk")->where("id_produk", $row['id_produk'])->single();

                $total_stok = $cek_produk['stok'] - $row['jumlah_pesanan'];





                $data_stok['stok'] = $total_stok;

                m_transaksi::update_stok($data_stok, $row['id_produk']);



            }



            };



            if (($aksi == 'tambah') ? m_transaksi::insert($data) : m_transaksi::update($data, url_segment(5)) )

            {

                redirect("administrator/general/transaksi");

            }



            

        }



        self::$data['transaksi'] = ($aksi == "perbaiki") ? m_transaksi::get_detail(url_segment(5)) : "";

        self::$data['act'] = $aksi;

        shl_loader::view("administrator/ultimo/general/transaksi", self::$data);

    }



    function laporan()

    {

        self::$data['act'] = 'laporan';

        shl_loader::view("administrator/ultimo/general/transaksi", self::$data);

    }



    function grafik()

    {

        self::$data['act'] = 'grafik';

        shl_loader::view("administrator/ultimo/general/transaksi", self::$data);

    }










}

?>