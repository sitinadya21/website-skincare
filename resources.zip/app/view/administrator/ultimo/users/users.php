<?php

ob_start();

?>

    <section class="content-header">

      <h1>

        Data Admin

      </h1>


    </section>

    <?php

    if (empty($act))

    {

    ?>

    <!-- Main content -->

    <section class="content">

      <div class="row">

        <div class="col-xs-12">

          <div class="box">

            <div class="box-header">

              <!-- <a class="btn btn-success btn-sm" href="<?=base_url();?>/administrator/users/users/tambah">

                            <i class="glyphicon glyphicon-plus"></i></a> -->

            </div>

            <!-- /.box-header -->

            <div class="box-body">

              <table id="example1" class="table table-bordered table-striped">

                <thead>

                <tr>

                                <th>No</th>

                                <th>Nama</th>

                                <th>Email</th>

                                <th class="text-center">Aksi</th>

                                

                    </a></th>

                </tr>

                </thead>

                <tbody>

                            <?php

                            $no = 0;

                            foreach ($users as $row)

                            {

                            $no++;

                            ?>

                            <tr>

                                <td><?=$no;?></td>

                                <td><?=$row['name'];?></td>

                                <td><?=$row['email'];?></td>


                                <td align="center">

                        <a class="btn btn-primary btn-sm" href="<?=base_url();?>/administrator/users/users/perbaiki/<?=$row['id_users'];?>">

                            <i class="glyphicon glyphicon-pencil"></i></a>
                            




                        </td>




                            </tr>

                            <?php } ?>

                </tbody>



              </table>

            </div>

            <!-- /.box-body -->

          </div>

          <!-- /.box -->

        </div>

        <!-- /.col -->

      </div>

      <!-- /.row -->

    </section>

    <!-- /.content -->

    <?php

    }

    else if ($act == "tambah")

    {

    ?>

    <form method="post" action="<?=base_url();?>/administrator/users/users/tambah" enctype="multipart/form-data">

    <!-- Main content -->

    <section class="content">

      <div class="row">

        <!-- left column -->

        <div class="col-md-12">

          <!-- general form elements -->

          <div class="box box-primary">

            <div class="box-header with-border">

              <h3 class="box-title">Data Admin</h3>

            </div>

            <!-- /.box-header -->

                         <div class="row">

            <div class="col-sm-12">

                <section class="panel default blue_title h4">

                    <div class="panel-body">

                        <div class="form-group">

                            <label for="exampleInputEmail1">Nama Admin</label>

                            <input class='form-control' type='text' name='name' value='' required/>

                        </div>


                        <div class="form-group">

                            <label for="exampleInputEmail1">Email</label>

                            <input class='form-control' type='email' name='email' value='' required/>

                        </div>

                        <div class="form-group">

                            <label for="exampleInputEmail1">Password</label>

                            <input class='form-control' type='password' name='password' value='' required/>

                        </div>






                    </div>

                </section>

            </div>



            <div class="col-sm-12">

                <section class="panel default blue_title h4">

                    <div class="panel-footer">

                        <button class="btn btn-primary" type="submit" onclick="return confirm('Yakin data akan disimpan ?')"><i class="fa fa-save"></i> Simpan</button>

                          <a class="btn btn-primary pull-right" href="<?=base_url();?>/administrator/users/users"> Kembali <i class="glyphicon glyphicon-arrow-left"></i></a>

                    </div>

                </section>

            </div>

        </div>



          </div>

          <!-- /.box -->







        </div>

        <!--/.col (left) -->



      </div>

      <!-- /.row -->

    </section>

    <!-- /.content -->

    </form>

    <?php

    }

    else if ($act == "perbaiki")

    {

    ?>

    <form method="post" action="<?=base_url();?>/administrator/users/users/perbaiki/<?=$users['id_users'];?>" enctype="multipart/form-data">

    <!-- Main content -->

    <section class="content">

      <div class="row">

        <!-- left column -->

        <div class="col-md-12">

          <!-- general form elements -->

          <div class="box box-primary">

            <div class="box-header with-border">

              <h3 class="box-title">Data Admin</h3>

            </div>

            <!-- /.box-header -->

                         <div class="row">

            <div class="col-sm-12">

                <section class="panel default blue_title h4">

                    <div class="panel-body">



                        <div class="form-group">

                            <label for="exampleInputEmail1">Nama Admin</label>

                            <input class='form-control' type='text' name='name' value='<?=$users['name'];?>' required/>

                        </div>


                        <div class="form-group">

                            <label for="exampleInputEmail1">Email</label>

                            <input class='form-control' type='email' name='email' value='<?=$users['email'];?>' required/>

                        </div>



                        <div class="form-group">

                            <label for="exampleInputEmail1">Password</label>

                            <input class='form-control' type='password' name='password' value='<?=$users['password'];?>' required/>

                        </div>





                    </div>

                </section>

            </div>



            <div class="col-sm-12">

                <section class="panel default blue_title h4">

                    <div class="panel-footer">

                        <button class="btn btn-primary" type="submit" onclick="return confirm('Yakin data akan disimpan ?')"><i class="fa fa-save"></i> Simpan</button>


                          <a class="btn btn-primary pull-right" href="<?=base_url();?>/administrator/users/users"> Kembali <i class="glyphicon glyphicon-arrow-left"></i></a>

                    </div>

                </section>

            </div>

        </div>



          </div>

          <!-- /.box -->







        </div>

        <!--/.col (left) -->



      </div>

      <!-- /.row -->

    </section>

    <!-- /.content -->

    </form>

    <?php

    }

    ?>

<?php shl_view::layout("administrator/ultimo/index", ob_get_clean());?>

