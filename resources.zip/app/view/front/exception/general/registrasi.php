	<?php

ob_start();

?>	

			<!-- Page Content -->

			<main class="page-main">

				<div class="block">

					<div class="container">

						<ul class="breadcrumbs">

							<li><a href="<?= base_url(); ?>"><i class="icon icon-home"></i></a></li>

							<li>/<span>Registrasi</span></li>



						</ul>

					</div>

				</div>

				<div class="block">

					<div class="container">

						<div class="form-card">

							<h3>Buat Akun</h3>

							<?php if (!empty($_GET['nt'])) { ?> 

							<p>Anda Berhasil Melakukan Registrasi, silahkan <a href="<?=base_url();?>/front/general/statis/login">Login </a></p>

							<?php };?>

							<form class="account-create" action="#" method="POST">

								<label>Nama<span class="required">*</span></label>

								<input type="text" name="nama" class="form-control input-lg" maxlength="25" required="required">

								<label>Nomor Telepon<span class="required">*</span></label>

								<input type="number" maxlength="13" name="telepon" class="form-control" required="required">

								<label>E-mail<span class="required">*</span></label>

								<input type="email" maxlength="35"  name="email" class="form-control input-lg" required="required">

								<label>Password<span class="required">*</span></label>

								<input type="password" name="password" class="form-control input-lg" maxlength="25" required="required">

								<div>

									<button class="btn btn-lg">Registrasi</button><span class="required-text">* Required Fields</span></div>

								<div>Sudah punya akun? <a href="<?=base_url();?>/front/general/statis/login" style="color: blue; font-weight: bold">Silahkan login <i class="icon icon-arrow-right"></i></a></div>

							</form>

						</div>

					</div>

				</div>

			</main>

			<!-- /Page Content -->



<?php

shl_view::layout("front/exception/index",ob_get_clean());

?>