<?php

ob_start();

?>



			<!-- Page Content -->

			<main class="page-main">



				<div class="block">

					<div class="container">

						<!-- Wellcome text -->

						<div class="text-center bottom-space">

							<h1 class="size-lg no-padding">Produk <span class="logo-font custom-color"><?=$_GET[id];?></span> Kami</h1>

							<div class="line-divider"></div>

							</p>

						</div>

						<!-- /Wellcome text -->

					</div>

				</div>





							<!-- Products Grid -->

							<div class="products-grid five-in-row product-variant-3">



								<?php 

								if(url_segment(4) == 'kategori') {

								

								$produk = shl_db::table("produk")->where("kategori_produk",$_GET['id'])->get();

								

								} else {



								$produk = shl_db::table("produk")->get();



								}



								foreach ($produk as $row) { 





								if(!empty(shl_session::get("id_pelanggan"))) { 

									$url = base_url()."/front/general/statis/detail_produk/".$row['id_produk'];

								} else {

									$url = base_url()."/front/general/statis/detail_produk/".$row['id_produk'];

								}





									$harga = $row['harga_produk'];

								



								





									?> 

								

								<!-- Product Item -->

								<div class="product-item large">

									<div class="product-item-inside">

										<!-- Product Label -->


										<!-- /Product Label -->

										<div class="product-item-info">

											<!-- Product Photo -->

											<div class="product-item-photo">

												<!-- product inside carousel -->

												<div class="carousel-inside fade" data-ride="carousel">

													<div class="carousel-inner">

														<div class="item active">

															<a href="<?=$url;?>"><img class="product-image-photo" src="<?=base_url();?>/resources/public/images/<?=$row['gambar_produk'];?>" alt=""></a>

														</div>



													</div>



												</div>

												<!-- /product inside carousel -->

												<!-- Product Actions -->

												<div class="product-item-actions">

													<div class="actions-primary">

														<a href="<?=$url;?>">

														<button class="btn btn-sm btn-invert add-to-cart"> <i class="icon icon-cart"></i><span>Beli</span> </button>

													</a>

													</div>





												</div>

												<!-- /Product Actions -->

											</div>

											<!-- /Product Photo -->

											<!-- Product Details -->

											<div class="product-item-details">

												<div class="product-item-name"> <a title="Boyfriend Short" href="<?=$url;?>" class="product-item-link"><?=$row['nama_produk'];?>  <br> Stok : <?=$row['stok'];?></a> </div>

												<div class="product-item-description"><?=$row['deskripsi_produk'];?> </div>

												<div class="price-box"> <span class="price-container"> <span class="price-wrapper">



												<span class="special-price"><?=rupiah($harga);?></span> </span>

													</span>

												</div>

												<!-- Product Actions -->

												<div class="product-item-actions">

													<div class="actions-primary">

														<a href="<?=$url;?>">

														<button class="btn btn-sm btn-invert add-to-cart" data-product="789123"> <i class="icon icon-cart"></i><span>Beli</span> </button>

													</a>

													</div>

												</div>

												<!-- /Product Actions -->

											</div>

											<!-- /Product Details -->

										</div>

									</div>

								</div>

								<!-- /Product Item -->

								<?php }; ?>



							</div>

							<!-- /Products Grid -->



			</main>

			<!-- /Page Content -->



<?php

shl_view::layout("front/exception/index",ob_get_clean());

?>