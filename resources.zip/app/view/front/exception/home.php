<?php

ob_start();

?>



<!-- Page Content -->

<main class="page-main">



	<div class="block fullwidth full-nopad bottom-space">

		<div class="container">

			<!-- Main Slider -->

			<div class="mainSlider" data-thumb="true" data-thumb-width="230" data-thumb-height="100">

				<div class="sliderLoader">Loading...</div>

				<!-- Slider main container -->

				<div class="swiper-container">

					<div class="swiper-wrapper">

						<!-- Slides -->

						<div class="swiper-slide" data-target="_blank">

							<!-- _blank or _self ( _self is default )-->

							<div class="wrapper">

								<figure><img src="<?= base_url(); ?>/resources/banner.jpg" alt=""></figure>



							</div>

						</div>

						<div class="swiper-slide" data-target="_blank">

							<!-- _blank or _self ( _self is default )-->

							<div class="wrapper">

								<figure><img src="<?= base_url(); ?>/resources/banner2.jpg" alt=""></figure>



							</div>

						</div>



					</div>

					<!-- pagination -->

					<div class="swiper-pagination"></div>

					<!-- pagination thumbs -->

					<div class="swiper-pagination-thumbs">

						<div class="thumbs-wrapper">

							<div class="thumbs"></div>

						</div>

					</div>

				</div>

			</div>

			<!-- /Main Slider -->

		</div>

	</div>

	<div class="block fullwidth full-nopad ">

		<div class="container">

			<!-- Category Slider -->

			<div class="category-slider">

				<div class="item">

					<a href="<?= base_url(); ?>/front/general/statis/kategori/?id=Pelembab">

						<img src="<?= base_url(); ?>/resources/pelembab.jpg" alt="">

						<div class="caption">

							<div class="text-style-1">Pelembab</div>

							<div class="btn">Belanja</div>

						</div>

					</a>

				</div>

				<div class="item">

					<a href="<?= base_url(); ?>/front/general/statis/kategori/?id=Pembersih+Wajah">

						<img src="<?= base_url(); ?>/resources/pembersihwajah.jpg" alt="">

						<div class="caption">

							<div class="text-style-1">Pembersih Wajah</div>

							<div class="btn">Belanja</div>

						</div>

					</a>

				</div>

				<div class="item">

					<a href="<?= base_url(); ?>/front/general/statis/kategori/?id=Sunscreen">

						<img src="<?= base_url(); ?>/resources/sunscreen.jpg" alt="">

						<div class="caption">

							<div class="text-style-1">Sunscreen</div>

							<div class="btn">Belanja</div>

						</div>

					</a>

				</div>

				<div class="item">

					<a href="<?= base_url(); ?>/front/general/statis/kategori/?id=Moisturizer">

						<img src="<?= base_url(); ?>/resources/moisturizer.jpg" alt="">

						<div class="caption">

							<div class="text-style-1">Moisturizer</div>

							<div class="btn">Belanja</div>

						</div>

					</a>

				</div>

				<div class="item">

					<a href="<?= base_url(); ?>/front/general/statis/kategori/?id=Makeup">

						<img src="<?= base_url(); ?>/resources/makeup.jpg" alt="">

						<div class="caption">

							<div class="text-style-1">Makeup</div>

							<div class="btn">Belanja</div>

						</div>

					</a>

				</div>




			</div>

			<!-- /Category Slider -->

		</div>

	</div>

	<div class="block">

		<div class="container">

			<!-- Wellcome text -->

			<div class="text-center bottom-space">

				<h1 class="size-lg no-padding"> <span class="logo-font custom-color">BEAUTYFY CLINIC</span></h1>

				<div class="line-divider"></div>

				<p class="custom-color-alt"> SELAMAT DATANG DI WEBSITE BEAUTYFY CLINIC

				<p class="custom-color-alt"> Klinik kecantikan Beautyfy merupakan sebuah tempat yang memberikan layanan profesional yang berkaitan dengan perawatan dan kecantikan kulit,meliputi proses peremajaan kulit,pencerahan kulit wajah, dan memperbaiki berbagai kekurangan yang muncul pada kulit. <br>
Klinik beautyfy memiliki tujuan untuk membantu meningkatkan kecantikan, mengatasi masalah kulit yang dialami, dan melakukan pemantauan jangka panjang. Setiap masalah kulit dan rencana perawatan kecantikan akan diawasi oleh dokter kulit, sehingga aman dan sesuai dengan kebutuhan.<br>
Kamu bisa datang ke klinik kecantikan . Saat mengalami masalah kulit, atau sekadar ingin mendapatkan treatment tertentu untuk meningkatkan kecantikan. Nantinya, dokter kulit akan memandu dan memberi saran, perawatan seperti apa yang terbaik, sesuai jenis dan kondisi kulit.<br>


				</p>

				</p>

			</div>


	<div class="products-grid five-in-row product-variant-3">

		<div class="title">

			<h2>Best Seller</h2>

			<div class="carousel-arrows"></div>

		</div>

		<?php

		$best = shl_db::sql_query("SELECT * FROM produk ORDER by Klik DESC")->limit(0, 5)->get();

		foreach ($best as $row) {

			if (!empty(shl_session::get("id_pelanggan"))) {

				$url = base_url() . "/front/general/statis/detail_produk/" . $row['id_produk'];
			} else {

				$url = base_url() . "/front/general/statis/detail_produk/" . $row['id_produk'];
			}


			$harga = $row['harga_produk'];

		?>



			<!-- Product Item -->

			<div class="product-item large">

				<div class="product-item-inside">

					<!-- Product Label -->



					<!-- /Product Label -->

					<div class="product-item-info">

						<!-- Product Photo -->

						<div class="product-item-photo">

							<!-- product inside carousel -->

							<div class="carousel-inside fade" data-ride="carousel">

								<div class="carousel-inner">

									<div class="item active">

										<a href="<?= $url; ?>"><img class="product-image-photo" src="<?= base_url(); ?>/resources/public/images/<?= $row['gambar_produk']; ?>" alt=""></a>

									</div>



								</div>

							</div>

							<!-- /product inside carousel -->

							<!-- Product Actions -->

							<div class="product-item-actions">

								<div class="actions-primary">

									<a href="<?= $url; ?>">

										<button class="btn btn-sm btn-invert add-to-cart"> <i class="icon icon-cart"></i><span>Order</span> </button>

									</a>

								</div>


							</div>

							<!-- /Product Actions -->

						</div>

						<!-- /Product Photo -->

						<!-- Product Details -->

						<div class="product-item-details">

							<div class="product-item-name"> <a title="Boyfriend Short" href="<?= $url; ?>" class="product-item-link"><?= $row['nama_produk']; ?> <br> Stok : <?= $row['stok']; ?></a> </div>

							<div class="product-item-description"><?= $row['deskripsi_produk']; ?> </div>

							<div class="price-box"> <span class="price-container"> <span class="price-wrapper"> <span class="old-price"></span> <br><span class="special-price"><?= rupiah($harga); ?></span> </span>

								</span>

							</div>

							<!-- Product Actions -->

							<div class="product-item-actions">

								<div class="actions-primary">

									<a href="<?= $url; ?>">

										<button class="btn btn-sm btn-invert add-to-cart" data-product="789123"> <i class="icon icon-cart"></i><span>Order</span> </button>

									</a>

								</div>

							</div>

							<!-- /Product Actions -->

						</div>

						<!-- /Product Details -->

					</div>

				</div>

			</div>

			<!-- /Product Item -->

		<?php }; ?>



	</div>

	<!-- /Products Grid -->


	<!-- Products Grid -->

	<div class="products-grid five-in-row product-variant-3">

		<div class="title">

			<h2>Semua Produk</h2>

			<div class="carousel-arrows"></div>

		</div>

		<?php

		$produk = shl_db::sql_query("SELECT * FROM produk")->get();

		foreach ($produk as $row) {

			if (!empty(shl_session::get("id_pelanggan"))) {

				$url = base_url() . "/front/general/statis/detail_produk/" . $row['id_produk'];
			} else {

				$url = base_url() . "/front/general/statis/detail_produk/" . $row['id_produk'];
			}



			$harga = $row['harga_produk'];

		?>



			<!-- Product Item -->

			<div class="product-item large">

				<div class="product-item-inside">

					<!-- Product Label -->


					<!-- /Product Label -->

					<div class="product-item-info">

						<!-- Product Photo -->

						<div class="product-item-photo">

							<!-- product inside carousel -->

							<div class="carousel-inside fade" data-ride="carousel">

								<div class="carousel-inner">

									<div class="item active">

										<a href="<?= $url; ?>"><img class="product-image-photo" src="<?= base_url(); ?>/resources/public/images/<?= $row['gambar_produk']; ?>" alt=""></a>

									</div>



								</div>



							</div>

							<!-- /product inside carousel -->

							<!-- Product Actions -->

							<div class="product-item-actions">

								<div class="actions-primary">

									<a href="<?= $url; ?>">

										<button class="btn btn-sm btn-invert add-to-cart"> <i class="icon icon-cart"></i><span>Order</span> </button>

									</a>

								</div>

							</div>

							<!-- /Product Actions -->

						</div>

						<!-- /Product Photo -->

						<!-- Product Details -->

						<div class="product-item-details">

							<div class="product-item-name"> <a title="Boyfriend Short" href="<?= $url; ?>" class="product-item-link"><?= $row['nama_produk']; ?> <br> Stok : <?= $row['stok']; ?></a> </div>

							<div class="product-item-description"><?= $row['deskripsi_produk']; ?> </div>

							<div class="price-box"> <span class="price-container"> <span class="price-wrapper"> <span class="old-price"></span> <br><span class="special-price"><?= rupiah($harga); ?></span> </span>

								</span>

							</div>

							<!-- Product Actions -->

							<div class="product-item-actions">

								<div class="actions-primary">

									<a href="<?= $url; ?>">

										<button class="btn btn-sm btn-invert add-to-cart" data-product="789123"> <i class="icon icon-cart"></i><span>Order</span> </button>

									</a>

								</div>

							</div>

							<!-- /Product Actions -->

						</div>

						<!-- /Product Details -->

					</div>

				</div>

			</div>

			<!-- /Product Item -->

		<?php }; ?>



	</div>

	<!-- /Products Grid -->





</main>

<!-- /Page Content -->

<?php

shl_view::layout("front/exception/index", ob_get_clean());

?>