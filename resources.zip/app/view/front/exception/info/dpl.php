<?php
ob_start();
?>
<!-- Page Content -->
<main class="page-main">
    <div class="container">
        <!-- Page Title -->
        <div class="page-title">
            <div class="title center">
                <h1>TREATMENT</h1>
            </div>
            <div class="text-wrapper">
                <p class="text-center">TREATMENT BEAUTY CLINIC</p>
            </div>
        </div>
        <!-- /Page Title -->
        <!-- Two columns -->
        <div class="row">
            <!-- Center column -->
            <div class="col-md-12">
                <div class="blog-post">

                    <div class="blog-content">
                        <h2 class="blog-title">DPL TREATMENT</h2>
                        <div class="blog-meta">
                            <div class="pull-left">
                                <span>BEAUTYFY CLINIC</span>

                            </div>

                        </div>
                        <div class="blog-text">
                            <p>
DPL adalah terapi perawatan kulit yang memanfaatkan cahaya lampu xenon. Cahaya lampu ini digunakan dalam gelombang intensitas tinggi untuk memperbaiki masalah kulit, seperti: mencerahkan wajah,
noda hitam penuaan,garis wajah dan kerutan, merontokkan bulu, bekas luka, serta
masalah jerawat


                            </p>
                        </div>
<center><img src="<?=base_url();?>/resources/treatment2.jpg" align=""style="width:400px;height:400px;"></center>
<br>
<center><font size="7">Rp 600.000</font><br></center>

                    </div>
                </div>
            </div>
            <!-- /Center column -->

        </div>
        <!-- /Two columns -->
    </div>
</main>
<!-- /Page Content -->
<?php
shl_view::layout("front/exception/index", ob_get_clean());
?>