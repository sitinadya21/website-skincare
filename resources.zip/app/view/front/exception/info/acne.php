<?php
ob_start();
?>
<!-- Page Content -->
<main class="page-main">
    <div class="container">
        <!-- Page Title -->
        <div class="page-title">
            <div class="title center">
                <h1>TREATMENT</h1>
            </div>
            <div class="text-wrapper">
                <p class="text-center">TREATMENT BEAUTY CLINIC</p>
            </div>
        </div>
        <!-- /Page Title -->
        <!-- Two columns -->
        <div class="row">
            <!-- Center column -->
            <div class="col-md-12">
                <div class="blog-post">

                    <div class="blog-content">
                        <h2 class="blog-title">ACNE SCARS </h2>
                        <div class="blog-meta">
                            <div class="pull-left">
                                <span>BEAUTYFY CLINIC</span>

                            </div>

                        </div>
                        <div class="blog-text">
                            <p>
Acne scar adalah bekas jerawat yang menyerupai bopeng di kulit wajah. Acne scar atau skar jerawat merupakan masalah kulit dalam suatu proses akhir dari penyembuhan jerawat aktif yang meradang. Umumnya Acne scar berbentuk seperti bekas jerawat yang berlubang atau bopeng pada kulit wajah. Pengobatan bekas jerawat memerlukan waktu yang cukup lama seiring dengan fase penyembuhan luka yang diharapkan untuk memperbaiki bekas jerawat sesuai tipe.Dengan begitu, bekas jerawat memerlukan terapi secara intensif dan berkesinambungan demi mendapatkan hasil yang optimal dan permanen.<br><br>
Metode treatment Acne scar ini dengan cara Microneedling atau subsisi yang dimana area bopeng akan di masukan serum dan di tekan sedikit demi sedikit untuk merangsang kolagen dan sel kulit baru sehingga bopeng dapat kembali rata seperti area kulit wajah yang lainnya.

                            </p>
                        </div>

<center><img src="<?=base_url();?>/resources/treatment1.jpg" align=""style="width:400px;height:400px;"></center>
<br>
<center><font size="7">Rp 550.000</font><br></center>
                    </div>
                </div>
            </div>
            <!-- /Center column -->

        </div>
        <!-- /Two columns -->
    </div>
</main>
<!-- /Page Content -->
<?php
shl_view::layout("front/exception/index", ob_get_clean());
?>