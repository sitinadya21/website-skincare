<?php
ob_start();
?>
<!-- Page Content -->
<main class="page-main">
    <div class="container">
        <!-- Page Title -->
        <div class="page-title">
            <div class="title center">
                <h1>PROMOSI</h1>
            </div>
            <div class="text-wrapper">
                <p class="text-center">PROMOSI BEAUTYFY CLINIC</p>
            </div>
        </div>
        <!-- /Page Title -->
        <!-- Two columns -->
        <div class="row">
            <!-- Center column -->
            <div class="col-md-3">
                <div class="blog-post">
                    <img src="<?=base_url();?>/resources/promo1.jpg" width="100%">

                </div>
            </div>
            <!-- /Center column -->

            <!-- Center column -->
            <div class="col-md-3">
                <div class="blog-post">
                    <img src="<?=base_url();?>/resources/promo2.jpg" width="100%">

                </div>
            </div>
            <!-- /Center column -->

            <!-- Center column -->
            <div class="col-md-3">
                <div class="blog-post">
                    <img src="<?=base_url();?>/resources/promo3.jpg" width="100%">

                </div>
            </div>
            <!-- /Center column -->

                        <!-- Center column -->
            <div class="col-md-3">
                <div class="blog-post">
                    <img src="<?=base_url();?>/resources/promo4.jpg" width="100%">

                </div>
            </div>
            <!-- /Center column -->


                        <!-- Center column -->
            <div class="col-md-3">
                <div class="blog-post">
                    <img src="<?=base_url();?>/resources/promo5.jpg" width="100%">

                </div>
            </div>
            <!-- /Center column -->

        </div>
        <!-- /Two columns -->
    </div>
</main>
<!-- /Page Content -->
<?php
shl_view::layout("front/exception/index", ob_get_clean());
?>