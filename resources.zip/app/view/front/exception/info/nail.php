<?php
ob_start();
?>
<!-- Page Content -->
<main class="page-main">
    <div class="container">
        <!-- Page Title -->
        <div class="page-title">
            <div class="title center">
                <h1>TREATMENT</h1>
            </div>
            <div class="text-wrapper">
                <p class="text-center">TREATMENT BEAUTY CLINIC</p>
            </div>
        </div>
        <!-- /Page Title -->
        <!-- Two columns -->
        <div class="row">
            <!-- Center column -->
            <div class="col-md-12">
                <div class="blog-post">

                    <div class="blog-content">
                        <h2 class="blog-title">NAIL ART  </h2>
                        <div class="blog-meta">
                            <div class="pull-left">
                                <span>BEAUTYFY CLINIC</span>

                            </div>

                        </div>
                        <div class="blog-text">
                            <p>
Nail art adalah seni melukis dan merias kuku dengan cara mengecat kuku tangan maupun kaki menggunakan bahan cat khusus untuk kuku. Tekhnik ini dapat berupa memberi gambar atau lukisan atau hiasan baik langsung diatas kuku maupun kuku plastik atau semacamnya yang disesuaikan dengan ukuran kuku. Metode Nail Art terdiri dari berbagai macam, antara lain Nail Art yang menggunakan acrylic, Nail Art yang menggunakan gel, dan Nail Art yang menggunakan kuku asli. Hal ini berkaitan dengan jenis dan bentuk Nail Art yang diinginkan konsumen yang setiap bentuknya memerlukan teknik yang berbeda.
                            </p>
                        </div>

<center><img src="<?=base_url();?>/resources/treatment6.jpg" align=""style="width:400px;height:400px;"></center>
<br>
<center><font size="7">Rp 130.000</font><br></center>

                    </div>
                </div>
            </div>
            <!-- /Center column -->

        </div>
        <!-- /Two columns -->
    </div>
</main>
<!-- /Page Content -->
<?php
shl_view::layout("front/exception/index", ob_get_clean());
?>