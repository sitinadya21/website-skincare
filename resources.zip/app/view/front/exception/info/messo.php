<?php
ob_start();
?>
<!-- Page Content -->
<main class="page-main">
    <div class="container">
        <!-- Page Title -->
        <div class="page-title">
            <div class="title center">
                <h1>TREATMENT</h1>
            </div>
            <div class="text-wrapper">
                <p class="text-center">TREATMENT BEAUTY CLINIC</p>
            </div>
        </div>
        <!-- /Page Title -->
        <!-- Two columns -->
        <div class="row">
            <!-- Center column -->
            <div class="col-md-12">
                <div class="blog-post">

                    <div class="blog-content">
                        <h2 class="blog-title">MESSO TREATMENT</h2>
                        <div class="blog-meta">
                            <div class="pull-left">
                                <span>BEAUTYFY CLINIC</span>

                            </div>

                        </div>
                        <div class="blog-text">
                            <p>
Messo wajah merupakan suatu metode kecantikan yang bertujuan untuk mengencangkan kulit dan menghilangkan kelebihan lemak pada bagian tubuh yang diinginkan.
Manfaat messo diantaranya: meremajakan (rejuvenate) dan mengencangkan kulit (skin tightening), memudarkan kerutan dan garis halus di wajah, Memudarkan pigmentasi kulit, seperti noda coklat dan flek hitam, Menghilangkan kelebihan lemak di bagian wajah, lengan, perut, kaki.

                            </p>
                        </div>

<center><img src="<?=base_url();?>/resources/treatment4.jpg" align=""style="width:400px;height:400px;"></center>
<br>
<center><font size="7">Rp 300.000</font><br></center>

                    </div>
                </div>
            </div>
            <!-- /Center column -->

        </div>
        <!-- /Two columns -->
    </div>
</main>
<!-- /Page Content -->
<?php
shl_view::layout("front/exception/index", ob_get_clean());
?>