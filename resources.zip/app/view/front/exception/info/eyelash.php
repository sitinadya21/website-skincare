<?php
ob_start();
?>
<!-- Page Content -->
<main class="page-main">
    <div class="container">
        <!-- Page Title -->
        <div class="page-title">
            <div class="title center">
                <h1>TREATMENT</h1>
            </div>
            <div class="text-wrapper">
                <p class="text-center">TREATMENT BEAUTY CLINIC</p>
            </div>
        </div>
        <!-- /Page Title -->
        <!-- Two columns -->
        <div class="row">
            <!-- Center column -->
            <div class="col-md-12">
                <div class="blog-post">

                    <div class="blog-content">
                        <h2 class="blog-title">EYELASH RUSSIAN</h2>
                        <div class="blog-meta">
                            <div class="pull-left">
                                <span>BEAUTYFY CLINIC</span>

                            </div>

                        </div>
                        <div class="blog-text">
                            <p>
Eyelash russian adalah proses penyambungan bulu mata buatan pada bulu mata asli satu persatu dengan bantuan lem khusus  agar bulu mata tampak lebih panjang, tebal, dan lentik. Proses pengerjaan biasanya memakan waktu sekitar 1,5 sampai 2 jam. Eyelash russian bisa bertahan selama 1 - 3 bulan.
                            </p>
                        </div>

<center><img src="<?=base_url();?>/resources/treatment3.jpg" align=""style="width:400px;height:400px;"></center>
<br>
<center><font size="7">Rp 200.000</font><br></center>

                    </div>
                </div>
            </div>
            <!-- /Center column -->

        </div>
        <!-- /Two columns -->
    </div>
</main>
<!-- /Page Content -->
<?php
shl_view::layout("front/exception/index", ob_get_clean());
?>