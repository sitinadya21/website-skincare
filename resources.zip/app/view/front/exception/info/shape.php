<?php
ob_start();
?>
<!-- Page Content -->
<main class="page-main">
    <div class="container">
        <!-- Page Title -->
        <div class="page-title">
            <div class="title center">
                <h1>TREATMENT</h1>
            </div>
            <div class="text-wrapper">
                <p class="text-center">TREATMENT BEAUTY CLINIC</p>
            </div>
        </div>
        <!-- /Page Title -->
        <!-- Two columns -->
        <div class="row">
            <!-- Center column -->
            <div class="col-md-12">
                <div class="blog-post">

                    <div class="blog-content">
                        <h2 class="blog-title">V SHAPE </h2>
                        <div class="blog-meta">
                            <div class="pull-left">
                                <span>BEAUTYFY CLINIC</span>

                            </div>

                        </div>
                        <div class="blog-text">
                            <p>
V-Shape adalah perawatan Radio Frequency non-ablatif yang efektif dan nyaman untuk merestruktur kondisi wajah agar berbentuk V dan merangsang produksi kolagen baru, sehingga kulit akan lebih halus, kencang, dan tampak lebih awet muda tanpa harus melakukan prosedur operasi.
                            </p>
                        </div>

<center><img src="<?=base_url();?>/resources/treatment5.jpg" align=""style="width:400px;height:400px;"></center>
<br>
<center><font size="7">Rp 8.000.000</font><br></center>

                    </div>
                </div>
            </div>
            <!-- /Center column -->

        </div>
        <!-- /Two columns -->
    </div>
</main>
<!-- /Page Content -->
<?php
shl_view::layout("front/exception/index", ob_get_clean());
?>