<?php
class m_statis extends shl_model
{
	static $table;

	function __construct()
	{
		self::$table = shl_db::table("halamanstatis");
	}

	static function get_data()
	{
		return self::$table;
	}

	static function get_detail($id)
	{
		return shl_db::table("halamanstatis")
					 ->select("*")
					 ->where("id_halaman", $id)->single();
	}


	static function insert($data)
	{
		return shl_db::table("halamanstatis")
				     ->insert($data);		
	}

	static function update($data,$id)
	{
		return shl_db::table("halamanstatis")
			 ->where("id_halaman", $id)
		     ->update($data);
	}

	static function delete($id)
	{
		return shl_db::table("halamanstatis")
			 ->where("id_halaman", $id)
		     ->delete();
	}
}
?>